#  Mobile Challenge Conexa
## Juan Francisco Bazán Carrizo

[Link Documento en Notion ](https://universal-fern-1dc.notion.site/Mobile-Challenge-Conexa-272dfea7db4b4c848d13d4bca6180036)


