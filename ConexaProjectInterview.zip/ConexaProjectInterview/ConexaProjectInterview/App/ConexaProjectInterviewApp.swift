//
//  ConexaProjectInterviewApp.swift
//  ConexaProjectInterview
//
//  Created by Juan Bazan Carrizo on 24/12/2023.
//

import SwiftUI

@main
struct ConexaProjectInterviewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
